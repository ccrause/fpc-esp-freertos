Getting started
===============

General note - paths and serial ports below are referenced in Linux style.  On Windows change /dev/ttyUSB0 to COM1 or equivalent.

0. Assume a working cross compiler for xtensa is available and that the required croos tools are installed.
1. Extract this archive to a folder.
2. Inform FPC where to locate tools/scripts by either
  a) Set an environment variable called IDF_PATH to the name of the destination folder in 1 above.
  b) Pass location of folder in 1 using the command line switch -Ff.
3. Pass libraries folder to FPC using -Fl(IDF_PATH)/libs, where (IDF_PATH) is the root of the extracted folder.
4. Also pass the bintools lib folder to FPC.  Something along the lines of -Fl(your-folder)/xtensa-lx106-elf/xtensa-lx106-elf/sysroot/lib

Blink something...
==================

1. Grab some SDK bindings and examples either by:
   a) git clone https://github.com/ccrause/fpc-esp-freertos.git
   b) download and unzip project from Github: https://github.com/ccrause/fpc-esp-freertos/archive/master.zip
   Substitute the actual location to this folder where (fpc-esp-freertos) is referenced below.

2. Open fpc-esp-freertos/examples/blink/blink.lpi in Lazarus. Select build mode ESP8266.
3. Ensure correctness of paths in project options.
4. Confirm GPIO number for LED constant in code.
4. Build project.
5. Optional, flash bootloader and partition table. Only required before first time use of the controller, or when the SDK configuration gets changed:
   (IDF_PATH)/components/esptool_py/esptool/esptool.py --chip auto --port /dev/ttyUSB0 --baud 500000 --before default_reset --after hard_reset write_flash -z --flash_mode dout --flash_freq 40m --flash_size 1MB 0x0000 (IDF_PATH)/libs/bootloader.bin 0x8000 (IDF_PATH)/libs/partitions_singleapp.bin

6. Flash project: (IDF_PATH8266)/components/esptool_py/esptool/esptool.py --chip auto --port /dev/ttyUSB0 --baud 500000 --before default_reset --after hard_reset write_flash -z --flash_mode dio --flash_freq 40m --flash_size 1MB 0x10000 (fpc-esp-freertos)/examples/blink/blink.bin

7. Optional, check serial output on serial monitor set to 8N1 and a baud rate of 115200. Or run the SDK provided command line serial monitor: (IDF_PATH)/tools/idf_monitor.py  --port /dev/ttyUSB0 (fpc-esp-freertos)/examples/blink/blink.elf
