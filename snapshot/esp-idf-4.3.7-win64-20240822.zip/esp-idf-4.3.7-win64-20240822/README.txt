1. This snapshot only contains ESP32 libraries and tools for Windows 10. First install xtensa-freertos for LX6 via fpcupdeluxe, then follow next steps to apply required files for Windows.
2. Delete the following sub folders in your fpcupdeluxe working folder:
   cross\bin\xtensa-freertos\bin\
   cross\bin\xtensa-freertos\esp-idf-4.3.2\
   cross\lib\xtensa-freertos\lx6\
3. Extract this zip file into fpcupdeluxe's cross folder.
4. Update fpcupdeluxe's fpc.cfg for ESP32 by looking for "#IFDEF CPULX6", then replace the original settings with:
#IFDEF CPULX6
-Cfhard
-FDC:\fpcupdeluxe\cross\bin\xtensa-freertos\bin\
-XPxtensa-esp32-elf-
-Wpesp32
-FfC:\fpcupdeluxe\cross\bin\xtensa-freertos\esp-idf-4.3.7
-FlC:\fpcupdeluxe\cross\bin\xtensa-freertos\esp-idf-4.3.7\components\esp_rom\esp32\ld\
-FlC:\fpcupdeluxe\cross\bin\xtensa-freertos\esp-idf-4.3.7\components\esp32\ld\
-FlC:\fpcupdeluxe\cross\lib\xtensa-freertos\lx6\
-WP4.3.7
#ENDIF CPULX6

Adjust all paths starting with "C:\fpcupdeluxe\cross\" with the location of your specific fpcupdeluxe folder structure.

5. To flash to an ESP32 controller board:
a) Optionally flash bootloader and a partition (only needs to be done once per controller, unlesss something breaks):
   C:\fpcupdeluxe\cross\bin\xtensa-freertos\esp-idf-4.3.7\components\esptool_py\esptool\esptool.py --chip auto -p com3 -b 115200 --before default_reset --after hard_reset  write_flash --flash_mode dio --flash_size detect --flash_freq 40m 0x1000 C:\fpcupdeluxe\cross\lib\xtensa-freertos\lx6\bootloader.bin 0x8000 C:\fpcupdeluxe\cross\lib\xtensa-freertos\lx6\partitions_singleapp.bin
b) Flash binary file:
   C:\fpcupdeluxe\cross\bin\xtensa-freertos\esp-idf-4.3.7\components\esptool_py\esptool\esptool.py --chip auto -p com3 -b 115200 --before default_reset --after hard_reset  write_flash --flash_mode dio --flash_size detect --flash_freq 40m 0x10000 blink.bin
