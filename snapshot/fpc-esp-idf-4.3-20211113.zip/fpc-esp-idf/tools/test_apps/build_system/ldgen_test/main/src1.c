#include <stdio.h>

void func1(void)
{
    printf("Hello from func1!\n");
}

void func2(void)
{
    printf("Hello from func2!\n");
}

void func3(void)
{
    printf("Hello from func3!\n");
}
