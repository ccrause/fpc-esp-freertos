# Build only test for C++

This test app ensures that calling all mqtt-client API could be called from C++
