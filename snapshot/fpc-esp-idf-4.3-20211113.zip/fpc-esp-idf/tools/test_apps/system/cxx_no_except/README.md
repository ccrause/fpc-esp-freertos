| Supported Targets | ESP32 | ESP32-C3 |
| ----------------- | ----- | -------- |
