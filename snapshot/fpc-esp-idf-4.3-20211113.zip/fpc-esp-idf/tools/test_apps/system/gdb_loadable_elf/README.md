# Loadable ELF test application

This project tests if the application can be loaded with GDB.
