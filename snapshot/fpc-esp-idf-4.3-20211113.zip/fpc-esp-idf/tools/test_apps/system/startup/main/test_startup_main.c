#include <stdio.h>

void app_main(void)
{
    printf("app_main running\n");
}
