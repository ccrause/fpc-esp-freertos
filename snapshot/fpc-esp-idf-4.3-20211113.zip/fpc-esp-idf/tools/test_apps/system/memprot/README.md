| Supported Targets | ESP32-S2 | ESP32-C3 |
| ----------------- | -------- | -------- |
