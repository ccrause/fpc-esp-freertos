# Project for testing the IDF monitor

Use `run_test_idf_monitor.py` in order to run the test.

New tests can be added into `test_list` of `run_test_idf_monitor.py` and placing the corresponding files into the
`tests` directory.

Note: The `idf_monitor` is tested with dummy ELF files. Run `make` to build the ELF files for supported architectures.
