This project tests if the app can start up in a certain configuration.
To add new configuration, create one more sdkconfig.ci.NAME file in this directory.

If you need to test for anything other than app starting up, create another test project.
