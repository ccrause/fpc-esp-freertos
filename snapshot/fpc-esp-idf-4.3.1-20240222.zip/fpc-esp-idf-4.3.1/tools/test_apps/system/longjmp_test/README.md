| Supported Targets | ESP32 | ESP32-S2 | ESP32-S3 |
| ----------------- | ----- | -------- | -------- |

# Building
Example building for ESP32:
```
idf.py set-target esp32
cp sdkconfig.defaults sdkconfig
idf.py build
```

# Running
All the setup needs to be done as described in the [test apps README](../../README.md).
