| Supported Targets | ESP32 | ESP32-S2 |
| ----------------- | ----- | -------- |
