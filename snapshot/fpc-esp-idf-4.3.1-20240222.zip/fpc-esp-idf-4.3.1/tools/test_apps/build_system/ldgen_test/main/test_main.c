
extern void func1(void);
extern void func2(void);
extern void func3(void);
extern void func4(void);


void app_main(void)
{
    func1();
    func2();
    func3();
    func4();
}
