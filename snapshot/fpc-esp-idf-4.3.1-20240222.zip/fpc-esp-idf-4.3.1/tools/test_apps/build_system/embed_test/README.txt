This project tests that proper identifiers are generated during build for embedded files.
