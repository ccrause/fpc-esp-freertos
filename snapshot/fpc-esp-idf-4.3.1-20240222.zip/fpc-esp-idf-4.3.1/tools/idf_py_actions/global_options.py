global_options = [{
    'names': ['-D', '--define-cache-entry'],
    'help': 'Create a cmake cache entry.',
    'scope': 'global',
    'multiple': True,
}]
