# espytrace Python package

This package implements base routines and classes for processing ESP32 application level trace data.
- `apptrace.py` includes functionality which is common for all types of trace data.
- `sysview.py` includes functionality which is specific for SystemView trace data format.
